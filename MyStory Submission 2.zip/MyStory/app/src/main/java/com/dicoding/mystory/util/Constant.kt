package com.dicoding.mystory.util


    const val SHARED_PREFERENCE_FILE_NAME = "SHARED_PREFERENCE_FILE_NAME"
    const val SHARED_PREFERENCE_PASSWORD = "283b65a4-cd14-46d7-921f-1f99f656a76b"
    const val TOKEN_SP_KEY = "token_sp_key"
    const val USER_ID_SP_KEY = "user_id_sp_key"
    const val NAME_SP_KEY = "name_sp_key"

    const val INITIAL_PAGE_INDEX = 1
    const val LOCATION = "1"

